public abstract class Personagem {
    private String nome;
    private int pvMaximo;
    private int pvAtual;
    private int agilidade;

    public Personagem(String nome, int pvMaximo, int agilidade) {
        this.nome = nome;
        this.pvMaximo = pvMaximo;
        this.pvAtual = pvMaximo;
        this.agilidade = agilidade;
    }
    
    public abstract int calcularDano();
    public abstract int getDefesa();
    
    public void receberDano(int dano) {
        this.pvAtual -= dano;
        if (this.pvAtual < 0) {
            this.pvAtual = 0;
        }
    }

    public boolean estaVivo() {
        return this.pvAtual > 0;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getPvMaximo() {
        return pvMaximo;
    }

    public void setPvMaximo(int pvMaximo) {
        this.pvMaximo = pvMaximo;
    }

    public int getPvAtual() {
        return pvAtual;
    }

    public void setPvAtual(int pvAtual) {
        this.pvAtual = pvAtual;
    }



    public int getAgilidade() {
        return agilidade;
    }

    public void setAgilidade(int agilidade) {
        this.agilidade = agilidade;
    }
}