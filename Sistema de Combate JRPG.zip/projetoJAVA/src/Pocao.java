public class Pocao {
    private int quantidade;

    public Pocao(int quantidadeInicial) {
        this.quantidade = quantidadeInicial;
    }

    public int usar() {
        if (quantidade > 0) {
            quantidade--;
            return Dado.rolarD6() + Dado.rolarD6() + Dado.rolarD6();
        }
        return 0;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
}