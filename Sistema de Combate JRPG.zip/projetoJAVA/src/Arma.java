public class Arma extends Equipamento {
    private String categoria;

    public Arma(String nome, int constanteK, String categoria) {
        super(nome, constanteK);
        this.categoria = categoria;
    }
    
    public int calcularDano(int forca, int destreza) {
        if ("Pesada".equalsIgnoreCase(this.categoria)) {
            return getConstanteK() + Dado.rolarD12() + (int) (1.5 * forca);
        } else if ("Leve".equalsIgnoreCase(this.categoria)) {
            return getConstanteK() + Dado.rolarD6() + Dado.rolarD6() + Dado.rolarD4() + destreza;
        }
        return 0;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
}