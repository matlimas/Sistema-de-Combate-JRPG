import java.util.Random;

public class Dado {
    private static final Random random = new Random();

    public static int rolarD4() {
        return random.nextInt(4) + 1;
    }

    public static int rolarD6() {
        return random.nextInt(6) + 1;
    }

    public static int rolarD12() {
        return random.nextInt(12) + 1;
    }
    
    public static int gerarNumero(int max) {
        return random.nextInt(max);
    }
}