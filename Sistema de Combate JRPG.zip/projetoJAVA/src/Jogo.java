import java.util.Scanner;
import java.util.Random;

public class Jogo {
    private static final Scanner scanner = new Scanner(System.in);
    private static Jogador jogador;

    public static void main(String[] args) {
        menuInicial();
    }

    private static void menuInicial() {
        while (true) {
            System.out.println("\n--- BEM-VINDO AO COMBATE JRPG ---");
            System.out.println("1. Comecar Jogo");
            System.out.println("2. Historia");
            System.out.println("3. Fechar Jogo");
            System.out.print("Escolha uma opcao: ");

            int escolha = scanner.nextInt();
            scanner.nextLine(); // Limpar buffer

            switch (escolha) {
                case 1:
                    iniciarJogo();
                    break;
                case 2:
                    mostrarHistoria();
                    break;
                case 3:
                    System.out.println("Obrigado por jogar!");
                    return;
                default:
                    System.out.println("Opcao invalida. Tente novamente.");
            }
        }
    }

    private static void mostrarHistoria() {
        System.out.println("\n--- HISTORIA ---");
        System.out.println("Em um reino assolado por criaturas sombrias, um heroi surge.");
        System.out.println("Seu destino e enfrentar tres guardioes amaldicoados para trazer a paz de volta.");
        System.out.println("Com coragem e aco, voce inicia sua jornada para se tornar uma lenda.");
        pressioneEnterParaContinuar();
    }

    private static void iniciarJogo() {
        jogador = criarPersonagem();

        if (executarCombate(1)) {
            primeiraPremiacao();
            if (executarCombate(2)) {
                segundaPremiacao();
                if (executarCombate(3)) {
                    telaDeVitoria();
                } else {
                    telaDeDerrota();
                }
            } else {
                telaDeDerrota();
            }
        } else {
            telaDeDerrota();
        }
    }

    private static Jogador criarPersonagem() {
        System.out.println("\n--- CRIACAO DE PERSONAGEM ---");
        System.out.print("Digite o nome do seu heroi: ");
        String nome = scanner.nextLine();

        int pontos = 15;
        int forca = 0, constituicao = 0, agilidade = 0, destreza = 0;
        
        System.out.println("Distribua 15 pontos entre os atributos (Forca, Constituicao, Agilidade, Destreza):");

        System.out.print("Pontos de Forca: ");
        forca = scanner.nextInt();
        pontos -= forca;
        
        System.out.print("Pontos de Constituicao (" + pontos + " restantes): ");
        constituicao = scanner.nextInt();
        pontos -= constituicao;

        System.out.print("Pontos de Agilidade (" + pontos + " restantes): ");
        agilidade = scanner.nextInt();
        pontos -= agilidade;

        destreza = pontos;
        System.out.println("Pontos de Destreza (restantes): " + destreza);
        
        Jogador novoJogador = new Jogador(nome, forca, constituicao, agilidade, destreza);

        Arma[] armasIniciais = {
            new Arma("Espadao de Ferro", 5, "Pesada"),
            new Arma("Adaga Afiada", 3, "Leve"),
            new Arma("Machado Rustico", 6, "Pesada")
        };
        System.out.println("\nEscolha sua arma inicial:");
        for (int i = 0; i < armasIniciais.length; i++) {
            System.out.println((i + 1) + ". " + armasIniciais[i].getNome());
        }
        int escolhaArma = scanner.nextInt() - 1;
        novoJogador.equiparArma(armasIniciais[escolhaArma]);

        Armadura[] armadurasIniciais = {
            new Armadura("Peitoral de Couro", 4),
            new Armadura("Cota de Malha", 6),
            new Armadura("Armadura de Placas Leve", 8)
        };
        System.out.println("\nEscolha sua armadura inicial:");
        for (int i = 0; i < armadurasIniciais.length; i++) {
            System.out.println((i + 1) + ". " + armadurasIniciais[i].getNome());
        }
        int escolhaArmadura = scanner.nextInt() - 1;
        novoJogador.equiparArmadura(armadurasIniciais[escolhaArmadura]);

        System.out.println("\n--- Personagem Criado ---");
        System.out.println("Nome: " + novoJogador.getNome());
        System.out.println("PV: " + novoJogador.getPvAtual());
        System.out.println("-------------------------");
        pressioneEnterParaContinuar();

        return novoJogador;
    }

    private static boolean executarCombate(int numeroCombate) {
        System.out.println("\n--- INICIANDO COMBATE " + numeroCombate + " ---");
        Adversario adversario = selecionarAdversario(numeroCombate);
        System.out.println("Voce enfrentara: " + adversario.getNome() + "!");
        
        jogador.iniciarPocoesDeCombate();
        
        boolean jogadorComeca = jogador.getAgilidade() >= adversario.getAgilidade();

        while(jogador.estaVivo() && adversario.estaVivo()) {
            System.out.println("\n--- STATUS ---");
            System.out.printf("%s: %d/%d PV\n", jogador.getNome(), jogador.getPvAtual(), jogador.getPvMaximo());
            System.out.printf("%s: %d/%d PV\n", adversario.getNome(), adversario.getPvAtual(), adversario.getPvMaximo());
            
            if (jogadorComeca) {
                turnoJogador(adversario);
                if (!adversario.estaVivo()) break;
                turnoAdversario(jogador, adversario);
            } else {
                turnoAdversario(jogador, adversario);
                if (!jogador.estaVivo()) break;
                turnoJogador(adversario);
            }
        }

        return jogador.estaVivo();
    }
    
    private static void turnoJogador(Adversario adversario) {
        System.out.println("\n--- SEU TURNO ---");
        System.out.println("1. Atacar");
        System.out.println("2. Defender");
        System.out.println("3. Usar Pocao");
        System.out.println("4. Usar Magia (Dano Puro)");
        System.out.print("Escolha sua acao: ");
        int escolha = scanner.nextInt();

        switch (escolha) {
            case 1:
                int danoJogador = jogador.calcularDano();
                int danoCausado = Math.max(0, danoJogador - adversario.getDefesa());
                adversario.receberDano(danoCausado);
                System.out.printf("%s ataca %s e causa %d de dano!\n", jogador.getNome(), adversario.getNome(), danoCausado);
                break;
            case 2:
                System.out.println(jogador.getNome() + " esta se defendendo! Defesa dobrada por um round.");
                break;
            case 3:
                jogador.usarPocao();
                break;
            case 4:
                int danoMagico = 15;
                adversario.receberDano(danoMagico);
                System.out.printf("%s usa uma magia e causa %d de dano puro em %s!\n", jogador.getNome(), danoMagico, adversario.getNome());
                break;
            default:
                System.out.println("Acao invalida. Voce perdeu o turno.");
                break;
        }
        pressioneEnterParaContinuar();
    }

    private static void turnoAdversario(Jogador jogador, Adversario adversario) {
        System.out.println("\n--- TURNO DO ADVERSARIO ---");
        int acao = Dado.gerarNumero(3);
        int defesaOriginal = adversario.getDefesa();

        switch(acao) {
            case 0:
                int danoAdversario = adversario.calcularDano();
                int danoRecebido = Math.max(0, danoAdversario - jogador.getDefesa());
                jogador.receberDano(danoRecebido);
                System.out.printf("%s ataca %s e causa %d de dano!\n", adversario.getNome(), jogador.getNome(), danoRecebido);
                break;
            case 1:
                 adversario.setDefesa(defesaOriginal * 2);
                 System.out.println(adversario.getNome() + " esta se defendendo! A defesa dobrou.");
                 break;
            case 2:
                 if (adversario.getPvAtual() < adversario.getPvMaximo() / 2) {
                    adversario.usarPocao();
                 } else {
                    int danoAdv = adversario.calcularDano();
                    int danoRec = Math.max(0, danoAdv - jogador.getDefesa());
                    jogador.receberDano(danoRec);
                    System.out.printf("%s ataca %s e causa %d de dano!\n", adversario.getNome(), jogador.getNome(), danoRec);
                 }
                 break;
        }
        if (acao == 1) {
            adversario.setDefesa(defesaOriginal);
        }
        pressioneEnterParaContinuar();
    }

    private static Adversario selecionarAdversario(int numeroCombate) {
        Adversario[] adversarios;
        switch (numeroCombate) {
            case 1:
                adversarios = new Adversario[]{
                    new Adversario("Goblin Sorrateiro", 50, 10, 15, 5),
                    new Adversario("Lobo Selvagem", 60, 12, 18, 3),
                    new Adversario("Esqueleto Guerreiro", 55, 8, 16, 8)
                };
                break;
            case 2:
                adversarios = new Adversario[]{
                    new Adversario("Ogro Brutal", 120, 5, 25, 12),
                    new Adversario("Mago Corrompido", 90, 15, 30, 8)
                };
                break;
            case 3:
                return new Adversario("Rei Demonio An'khara", 250, 20, 40, 20);
            default:
                return new Adversario("Dummy", 1, 1, 1, 1);
        }
        return adversarios[new Random().nextInt(adversarios.length)];
    }

    private static void primeiraPremiacao() {
        System.out.println("\n--- VITORIA NO PRIMEIRO COMBATE! ---");
        System.out.println("Voce subiu de nivel!");
        System.out.println("Voce ganhou 5 pontos de atributo para distribuir.");
        jogador.setForca(jogador.getForca() + 5); 
        System.out.println("5 pontos adicionados em Forca!");
        
        jogador.aumentarPVMaximo();
        System.out.println("Seu PV maximo aumentou! PV atual: " + jogador.getPvAtual() + "/" + jogador.getPvMaximo());
        
        Arma[] novasArmas = {
            new Arma("Lamina do Guerreiro", 10, "Pesada"),
            new Arma("Cimitarra Veloz", 8, "Leve"),
            new Arma("Martelo de Guerra", 12, "Pesada")
        };
        System.out.println("\nEscolha sua nova arma:");
        for (int i = 0; i < novasArmas.length; i++) {
            System.out.println((i + 1) + ". " + novasArmas[i].getNome());
        }
        int escolhaArma = scanner.nextInt() - 1;
        jogador.equiparArma(novasArmas[escolhaArma]);
        pressioneEnterParaContinuar();
    }
    
    private static void segundaPremiacao() {
        System.out.println("\n--- VITORIA NO SEGUNDO COMBATE! ---");
        System.out.println("Voce subiu dois niveis!");
        System.out.println("Voce ganhou 10 pontos de atributo para distribuir.");
        jogador.setForca(jogador.getForca() + 5);
        jogador.setConstituicao(jogador.getConstituicao() + 5);
        System.out.println("5 pontos adicionados em Forca e 5 em Constituicao!");

        jogador.aumentarPVMaximo();
        System.out.println("Seu PV maximo aumentou! PV atual: " + jogador.getPvAtual() + "/" + jogador.getPvMaximo());
        
        Armadura[] novasArmaduras = {
            new Armadura("Armadura de Aco Reforcado", 12),
            new Armadura("Brigantina Elfica", 10),
            new Armadura("Placas de Cavaleiro", 15)
        };
        System.out.println("\nEscolha sua nova armadura:");
        for (int i = 0; i < novasArmaduras.length; i++) {
            System.out.println((i + 1) + ". " + novasArmaduras[i].getNome());
        }
        int escolhaArmadura = scanner.nextInt() - 1;
        jogador.equiparArmadura(novasArmaduras[escolhaArmadura]);
        pressioneEnterParaContinuar();
    }
    
    private static void telaDeVitoria() {
        System.out.println("\n***********************************");
        System.out.println("            VITORIA!");
        System.out.println("***********************************");
        System.out.println("Voce derrotou o ultimo guardiao e trouxe a paz de volta ao reino.");
        System.out.println("Seu nome, " + jogador.getNome() + ", sera cantado por geracoes.");
        System.out.println("FIM DE JOGO. Obrigado por jogar!");
        pressioneEnterParaContinuar();
    }

    private static void telaDeDerrota() {
        System.out.println("\n###################################");
        System.out.println("           VOCE FOI DERROTADO!");
        System.out.println("###################################");
        System.out.println("Sua jornada termina aqui, mas a esperanca nunca morre.");
        System.out.println("Tente novamente e conquiste seu destino.");
        pressioneEnterParaContinuar();
    }

    private static void pressioneEnterParaContinuar() {
        System.out.println("\n(Pressione ENTER para continuar...)");
        scanner.nextLine();
    }
}