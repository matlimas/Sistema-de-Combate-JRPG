public class Armadura extends Equipamento {

    public Armadura(String nome, int constanteK) {
        super(nome, constanteK);
    }

    public int calcularDefesa(int constituicao) {
        return getConstanteK() + (int) (1.5 * constituicao);
    }
}