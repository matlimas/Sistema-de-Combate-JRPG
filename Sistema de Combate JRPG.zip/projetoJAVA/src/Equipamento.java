public class Equipamento {
    private String nome;
    private int constanteK;

    public Equipamento(String nome, int constanteK) {
        this.nome = nome;
        this.constanteK = constanteK;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getConstanteK() {
        return constanteK;
    }

    public void setConstanteK(int constanteK) {
        this.constanteK = constanteK;
    }
}