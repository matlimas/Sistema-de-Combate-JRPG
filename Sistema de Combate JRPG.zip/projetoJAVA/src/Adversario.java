public class Adversario extends Personagem {
    private int dano;
    private int defesa;
    private Pocao pocao;

    public Adversario(String nome, int pvMaximo, int agilidade, int dano, int defesa) {
        super(nome, pvMaximo, agilidade);
        this.dano = dano;
        this.defesa = defesa;
        this.pocao = new Pocao(1);
    }

    @Override
    public int calcularDano() {
        return this.dano;
    }
    
    @Override
    public int getDefesa() {
        return this.defesa;
    }
    
    public void setDefesa(int defesa){
        this.defesa = defesa;
    }
    
    public void usarPocao() {
        if (pocao.getQuantidade() > 0) {
            int cura = pocao.usar();
            setPvAtual(getPvAtual() + cura);
            if(getPvAtual() > getPvMaximo()){
                setPvAtual(getPvMaximo());
            }
            System.out.println(getNome() + " usou uma pocao e recuperou " + cura + " de PV!");
        }
    }
}