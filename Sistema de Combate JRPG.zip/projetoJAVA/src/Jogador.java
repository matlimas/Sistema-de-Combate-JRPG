public class Jogador extends Personagem {
    private int forca;
    private int constituicao;
    private int destreza;

    private Arma arma;
    private Armadura armadura;
    private Pocao pocaoDeCombate;

    public Jogador(String nome, int forca, int constituicao, int agilidade, int destreza) {
        super(nome, Dado.rolarD6() + Dado.rolarD6() + Dado.rolarD6() + constituicao, agilidade);
        this.forca = forca;
        this.constituicao = constituicao;
        this.destreza = destreza;
    }

    @Override
    public int calcularDano() {
        if (this.arma != null) {
            return this.arma.calcularDano(this.forca, this.destreza);
        }
        return this.forca;
    }

    @Override
    public int getDefesa() {
        if (this.armadura != null) {
            return this.armadura.calcularDefesa(this.constituicao);
        }
        return 0;
    }

    public void equiparArma(Arma arma) {
        this.arma = arma;
        System.out.println(getNome() + " equipou: " + arma.getNome());
    }

    public void equiparArmadura(Armadura armadura) {
        this.armadura = armadura;
        System.out.println(getNome() + " equipou: " + armadura.getNome());
    }
    
    public void iniciarPocoesDeCombate() {
        this.pocaoDeCombate = new Pocao(3);
    }

    public void usarPocao() {
        if (this.pocaoDeCombate.getQuantidade() > 0) {
            int cura = this.pocaoDeCombate.usar();
            setPvAtual(getPvAtual() + cura);
            if (getPvAtual() > getPvMaximo()) {
                setPvAtual(getPvMaximo());
            }
            System.out.println(getNome() + " usou uma pocao e recuperou " + cura + " de PV!");
            System.out.println("Pocoes restantes: " + this.pocaoDeCombate.getQuantidade());
        } else {
            System.out.println("Voce nao tem mais pocoes neste combate!");
        }
    }
    
    public void distribuirPontos(int pontos) {
        this.forca += pontos;
    }
    
    public void aumentarPVMaximo() {
        setPvMaximo(getPvMaximo() + this.constituicao);
        setPvAtual(getPvMaximo());
    }

    public int getForca() {
        return forca;
    }

    public void setForca(int forca) {
        this.forca = forca;
    }

    public int getConstituicao() {
        return constituicao;
    }

    public void setConstituicao(int constituicao) {
        this.constituicao = constituicao;
    }

    public int getDestreza() {
        return destreza;
    }

    public void setDestreza(int destreza) {
        this.destreza = destreza;
    }
    
    public Arma getArma() {
        return arma;
    }
    
    public Armadura getArmadura() {
        return armadura;
    }
}